from pathlib import Path
import os
values = [(-1)**n for n in range(10)]
print(values)
Path(os.environ['SCHEMAMATH_OUTPUT_DIR'], 'parity.json').write_text(__import__('json').dumps(values), encoding='utf-8')
